﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Frany Berroa
// GUI Assignment

namespace Assignment_GUI
{
    public partial class Form1 : Form
    {
        //Variables
        int num1;
        public Form1()
        {
            InitializeComponent();
        }

        private void BTNSubmit_Click(object sender, EventArgs e)
        {
            if (int.TryParse(TBintCheck.Text, out num1))
            {
                MessageBox.Show("Great pick!!!");
            }
            else
            {
                MessageBox.Show("Please enter a valid number");
            }            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void CBRainny_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Don't forget your umbrella!");
        }

        private void CBCloudy_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Bring the umbrella, just in case!");
        }

        private void CBFoggy_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Be careful at dusk/dawn!");
        }

        private void CBWindy_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Hold on to your hat!");
        }

        private void CBSunny_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("At leas it is not raining!");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void RBYes_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void RBNo_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void BtnActivities_Click(object sender, EventArgs e)
        {
            if (RBYes.Checked)
            {
                MessageBox.Show("Sweet!");
            }
            else if (RBNo.Checked)
            {
                MessageBox.Show("You should try going out more!"); 
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void RBSpring_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void BTNSeason_Click(object sender, EventArgs e)
        {
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void RBFall_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void BTNSeason_Click_1(object sender, EventArgs e)
        {

            if (RBSpring.Checked)
            {
                string path = Directory.GetCurrentDirectory();
                string imagePath = Path.Combine(path, "images", "Spring.png");
                pictureBox1.ImageLocation = imagePath;
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
            else if (RBFall.Checked)
            {
                string path = Directory.GetCurrentDirectory();
                string imagePath = Path.Combine(path, "images", "Fall.png");
                pictureBox1.ImageLocation = imagePath;
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
            else if (RBWinter.Checked)
            {
                string path = Directory.GetCurrentDirectory();
                string imagePath = Path.Combine(path, "images", "Winter.png");
                pictureBox1.ImageLocation = imagePath;
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
            else if (RBSummer.Checked)
            {
                string path = Directory.GetCurrentDirectory();
                string imagePath = Path.Combine(path, "images", "Summer.png");
                pictureBox1.ImageLocation = imagePath;
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string url = "https://www.weather.com/weather/today";
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }
    }
}
