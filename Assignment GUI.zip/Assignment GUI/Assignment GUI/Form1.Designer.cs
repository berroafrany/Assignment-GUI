﻿namespace Assignment_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.RBSpring = new System.Windows.Forms.RadioButton();
            this.RBSummer = new System.Windows.Forms.RadioButton();
            this.RBFall = new System.Windows.Forms.RadioButton();
            this.RBWinter = new System.Windows.Forms.RadioButton();
            this.CBRainny = new System.Windows.Forms.CheckBox();
            this.CBCloudy = new System.Windows.Forms.CheckBox();
            this.CBFoggy = new System.Windows.Forms.CheckBox();
            this.CBWindy = new System.Windows.Forms.CheckBox();
            this.CBSunny = new System.Windows.Forms.CheckBox();
            this.RBYes = new System.Windows.Forms.RadioButton();
            this.RBNo = new System.Windows.Forms.RadioButton();
            this.BTNSubmit = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.TBintCheck = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnActivities = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.BTNSeason = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BTNCurrentWeather = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // RBSpring
            // 
            this.RBSpring.AutoSize = true;
            this.RBSpring.Location = new System.Drawing.Point(15, 25);
            this.RBSpring.Name = "RBSpring";
            this.RBSpring.Size = new System.Drawing.Size(55, 17);
            this.RBSpring.TabIndex = 6;
            this.RBSpring.TabStop = true;
            this.RBSpring.Text = "Spring";
            this.RBSpring.UseVisualStyleBackColor = true;
            this.RBSpring.CheckedChanged += new System.EventHandler(this.RBSpring_CheckedChanged);
            // 
            // RBSummer
            // 
            this.RBSummer.AutoSize = true;
            this.RBSummer.Location = new System.Drawing.Point(15, 89);
            this.RBSummer.Name = "RBSummer";
            this.RBSummer.Size = new System.Drawing.Size(63, 17);
            this.RBSummer.TabIndex = 7;
            this.RBSummer.TabStop = true;
            this.RBSummer.Text = "Summer";
            this.RBSummer.UseVisualStyleBackColor = true;
            // 
            // RBFall
            // 
            this.RBFall.AutoSize = true;
            this.RBFall.Location = new System.Drawing.Point(15, 46);
            this.RBFall.Name = "RBFall";
            this.RBFall.Size = new System.Drawing.Size(41, 17);
            this.RBFall.TabIndex = 8;
            this.RBFall.TabStop = true;
            this.RBFall.Text = "Fall";
            this.RBFall.UseVisualStyleBackColor = true;
            this.RBFall.CheckedChanged += new System.EventHandler(this.RBFall_CheckedChanged);
            // 
            // RBWinter
            // 
            this.RBWinter.AutoSize = true;
            this.RBWinter.Location = new System.Drawing.Point(15, 69);
            this.RBWinter.Name = "RBWinter";
            this.RBWinter.Size = new System.Drawing.Size(56, 17);
            this.RBWinter.TabIndex = 9;
            this.RBWinter.TabStop = true;
            this.RBWinter.Text = "Winter";
            this.RBWinter.UseVisualStyleBackColor = true;
            // 
            // CBRainny
            // 
            this.CBRainny.AutoSize = true;
            this.CBRainny.Location = new System.Drawing.Point(11, 19);
            this.CBRainny.Name = "CBRainny";
            this.CBRainny.Size = new System.Drawing.Size(59, 17);
            this.CBRainny.TabIndex = 10;
            this.CBRainny.Text = "Rainny";
            this.CBRainny.UseVisualStyleBackColor = true;
            this.CBRainny.CheckedChanged += new System.EventHandler(this.CBRainny_CheckedChanged);
            // 
            // CBCloudy
            // 
            this.CBCloudy.AutoSize = true;
            this.CBCloudy.Location = new System.Drawing.Point(11, 40);
            this.CBCloudy.Name = "CBCloudy";
            this.CBCloudy.Size = new System.Drawing.Size(58, 17);
            this.CBCloudy.TabIndex = 11;
            this.CBCloudy.Text = "Cloudy";
            this.CBCloudy.UseVisualStyleBackColor = true;
            this.CBCloudy.CheckedChanged += new System.EventHandler(this.CBCloudy_CheckedChanged);
            // 
            // CBFoggy
            // 
            this.CBFoggy.AutoSize = true;
            this.CBFoggy.Location = new System.Drawing.Point(11, 106);
            this.CBFoggy.Name = "CBFoggy";
            this.CBFoggy.Size = new System.Drawing.Size(55, 17);
            this.CBFoggy.TabIndex = 12;
            this.CBFoggy.Text = "Foggy";
            this.CBFoggy.UseVisualStyleBackColor = true;
            this.CBFoggy.CheckedChanged += new System.EventHandler(this.CBFoggy_CheckedChanged);
            // 
            // CBWindy
            // 
            this.CBWindy.AutoSize = true;
            this.CBWindy.Location = new System.Drawing.Point(11, 83);
            this.CBWindy.Name = "CBWindy";
            this.CBWindy.Size = new System.Drawing.Size(56, 17);
            this.CBWindy.TabIndex = 13;
            this.CBWindy.Text = "Windy";
            this.CBWindy.UseVisualStyleBackColor = true;
            this.CBWindy.CheckedChanged += new System.EventHandler(this.CBWindy_CheckedChanged);
            // 
            // CBSunny
            // 
            this.CBSunny.AutoSize = true;
            this.CBSunny.Location = new System.Drawing.Point(11, 63);
            this.CBSunny.Name = "CBSunny";
            this.CBSunny.Size = new System.Drawing.Size(56, 17);
            this.CBSunny.TabIndex = 14;
            this.CBSunny.Text = "Sunny";
            this.CBSunny.UseVisualStyleBackColor = true;
            this.CBSunny.CheckedChanged += new System.EventHandler(this.CBSunny_CheckedChanged);
            // 
            // RBYes
            // 
            this.RBYes.AutoSize = true;
            this.RBYes.Location = new System.Drawing.Point(32, 19);
            this.RBYes.Name = "RBYes";
            this.RBYes.Size = new System.Drawing.Size(43, 17);
            this.RBYes.TabIndex = 16;
            this.RBYes.TabStop = true;
            this.RBYes.Text = "Yes";
            this.RBYes.UseVisualStyleBackColor = true;
            this.RBYes.CheckedChanged += new System.EventHandler(this.RBYes_CheckedChanged);
            // 
            // RBNo
            // 
            this.RBNo.AutoSize = true;
            this.RBNo.Location = new System.Drawing.Point(32, 35);
            this.RBNo.Name = "RBNo";
            this.RBNo.Size = new System.Drawing.Size(39, 17);
            this.RBNo.TabIndex = 17;
            this.RBNo.TabStop = true;
            this.RBNo.Text = "No";
            this.RBNo.UseVisualStyleBackColor = true;
            this.RBNo.CheckedChanged += new System.EventHandler(this.RBNo_CheckedChanged);
            // 
            // BTNSubmit
            // 
            this.BTNSubmit.BackColor = System.Drawing.Color.DodgerBlue;
            this.BTNSubmit.Location = new System.Drawing.Point(252, 68);
            this.BTNSubmit.Name = "BTNSubmit";
            this.BTNSubmit.Size = new System.Drawing.Size(144, 50);
            this.BTNSubmit.TabIndex = 20;
            this.BTNSubmit.Text = "Click HERE if entered your favorite number";
            this.BTNSubmit.UseVisualStyleBackColor = false;
            this.BTNSubmit.Click += new System.EventHandler(this.BTNSubmit_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(249, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Enter your favorite number";
            // 
            // TBintCheck
            // 
            this.TBintCheck.Location = new System.Drawing.Point(386, 42);
            this.TBintCheck.Name = "TBintCheck";
            this.TBintCheck.Size = new System.Drawing.Size(41, 20);
            this.TBintCheck.TabIndex = 22;
            this.TBintCheck.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.BtnActivities);
            this.groupBox1.Controls.Add(this.RBYes);
            this.groupBox1.Controls.Add(this.RBNo);
            this.groupBox1.Location = new System.Drawing.Point(29, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(166, 92);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Do you like outdoor activities?";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // BtnActivities
            // 
            this.BtnActivities.Location = new System.Drawing.Point(18, 54);
            this.BtnActivities.Name = "BtnActivities";
            this.BtnActivities.Size = new System.Drawing.Size(85, 32);
            this.BtnActivities.TabIndex = 18;
            this.BtnActivities.Text = "Submit";
            this.BtnActivities.UseVisualStyleBackColor = true;
            this.BtnActivities.Click += new System.EventHandler(this.BtnActivities_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.CBRainny);
            this.groupBox2.Controls.Add(this.CBCloudy);
            this.groupBox2.Controls.Add(this.CBSunny);
            this.groupBox2.Controls.Add(this.CBWindy);
            this.groupBox2.Controls.Add(this.CBFoggy);
            this.groupBox2.Location = new System.Drawing.Point(29, 242);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(189, 134);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "What is your favority weather?";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.BTNSeason);
            this.groupBox3.Controls.Add(this.RBSpring);
            this.groupBox3.Controls.Add(this.RBFall);
            this.groupBox3.Controls.Add(this.RBWinter);
            this.groupBox3.Controls.Add(this.RBSummer);
            this.groupBox3.Location = new System.Drawing.Point(252, 235);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(164, 142);
            this.groupBox3.TabIndex = 25;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "What is your favority season?";
            // 
            // BTNSeason
            // 
            this.BTNSeason.Location = new System.Drawing.Point(42, 113);
            this.BTNSeason.Name = "BTNSeason";
            this.BTNSeason.Size = new System.Drawing.Size(65, 28);
            this.BTNSeason.TabIndex = 10;
            this.BTNSeason.Text = "Submit";
            this.BTNSeason.UseVisualStyleBackColor = true;
            this.BTNSeason.Click += new System.EventHandler(this.BTNSeason_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Location = new System.Drawing.Point(447, 161);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(178, 216);
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BTNCurrentWeather
            // 
            this.BTNCurrentWeather.Location = new System.Drawing.Point(186, 138);
            this.BTNCurrentWeather.Name = "BTNCurrentWeather";
            this.BTNCurrentWeather.Size = new System.Drawing.Size(69, 81);
            this.BTNCurrentWeather.TabIndex = 27;
            this.BTNCurrentWeather.Text = "Click me if you would like to know the current weather!";
            this.BTNCurrentWeather.UseVisualStyleBackColor = true;
            this.BTNCurrentWeather.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Assignment_GUI.Properties.Resources.Background1;
            this.ClientSize = new System.Drawing.Size(822, 504);
            this.Controls.Add(this.BTNCurrentWeather);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TBintCheck);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.BTNSubmit);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton RBSpring;
        private System.Windows.Forms.RadioButton RBSummer;
        private System.Windows.Forms.RadioButton RBFall;
        private System.Windows.Forms.RadioButton RBWinter;
        private System.Windows.Forms.CheckBox CBRainny;
        private System.Windows.Forms.CheckBox CBCloudy;
        private System.Windows.Forms.CheckBox CBFoggy;
        private System.Windows.Forms.CheckBox CBWindy;
        private System.Windows.Forms.CheckBox CBSunny;
        private System.Windows.Forms.RadioButton RBYes;
        private System.Windows.Forms.RadioButton RBNo;
        private System.Windows.Forms.Button BTNSubmit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TBintCheck;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnActivities;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BTNSeason;
        private System.Windows.Forms.Button BTNCurrentWeather;
    }
}

